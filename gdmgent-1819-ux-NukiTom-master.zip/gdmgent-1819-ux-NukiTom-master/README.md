# Eindopdracht UX

- Voornaam: Tom 
- Familienaam: Van Damme
- Studentnummer: 104101
- Klasgroep: 1 MMPa
- UX prototype link: 
                computer:  https://xd.adobe.com/view/ce76977f-2d20-4834-7b4d-28f671e8ce6b-b847/
                smartphone: https://xd.adobe.com/view/9a1ed10e-1372-4174-64b5-28f6c7ef10cd-ec2f/
